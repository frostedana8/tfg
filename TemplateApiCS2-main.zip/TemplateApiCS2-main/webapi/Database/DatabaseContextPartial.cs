﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using webapi.Database.Models;

namespace webapi.Database;

public partial class DatabaseContext : DbContext
{
}
